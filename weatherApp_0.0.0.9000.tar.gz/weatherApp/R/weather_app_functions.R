### weather_app in R Shiny ###

library(httr)
library(jsonlite)
library(dplyr)
library(leaflet)
library(mapview)
library(magick)
library(stringr)
# library(tidygeocoder)

# you will need an API key to access the data from openweathermaps.org
# you have to sign up for a free account to get the api key
# the api key is private and should not be shared with other people

# my_api_key <- "insert your api key here"

# tidygeocoder::geo_osm() uses a string with an address as input and returns
# the latitude and longitude of the location. The tidygeocoder::geo_osm() function was substituted with my own function geocode().

# The function geocode() takes a location as input and returns the longitude and latitude of this location.
# This way, I don't need to install and use the external function tidygeocoder::geo_osm() anymore.

#' @export
geocode <- function(location){

  # split the location string, that the function got as input, into the different words.
  my_location <- stringr::str_split(location, boundary("word"))
  my_location_string <- my_location[[1]][1]

  for(i in 2:length(my_location[[1]])){
    my_location_string <- paste(my_location_string, "+", my_location[[1]][i], sep = "")
  }

  # Write down the url that retrieves the long/lat information from openstreetmap.org

  my_url <- paste("https://nominatim.openstreetmap.org/search?q=", my_location_string,
                  "&format=json&limit=1", sep="")

  # call the Url, retrieve the data and check if it was successful.
  my_raw_results <- httr::GET(my_url)

  if (status_code(my_raw_results)[[1]] != 200) {
    stop("Please enter a valid location!")
  }

  # Transform the JSON data into useable format.
  my_content <- httr::content(my_raw_results, as = "text")

  my_content_from_json <- jsonlite::fromJSON(my_content)

  # Save the longitude latitude data in an object and return it.
  geocode_data <- data.frame(3)
  geocode_data$location <- location
  geocode_data$latitude <- my_content_from_json$lat
  geocode_data$longitude <- my_content_from_json$lon

  return(geocode_data)

}

# Example for geocode()
# geocode("Amsterdam, Netherlands")


# The following function takes the location (in string format) and your apiKey (in string format) as input.
# The function returns the weather data for a specific location as a list.
# The weather data are provided by www.openweathermap.org

#' @export
get_weather <- function(location, apiKey) {

  # first, we need to use the function geocode(location) to get the longitude and the latitude of the desired location.

  latitude <- geocode(location)$latitude
  longitude <- geocode(location)$longitude

  # latitude <- tidygeocoder::geo_osm(location)$lat[1] # old version
  # longitude <- tidygeocoder::geo_osm(location)$long[1] # old version

  if (is.na(latitude) | is.na(longitude)) {

    stop("Please type in a valid location")

  }

  # now, we access www.openweatherapp.org and retrieve the weather data.

  my_url <- paste0("https://api.openweathermap.org/data/2.5/onecall?lat=", latitude, "&lon=", longitude,
                  "&exclude=FALSE&appid=", apiKey)

  # We retrieve the data using the url
  my_raw_results <- httr::GET(my_url)

  # We check whether we successfully retrieved data from the API.

  if (status_code(my_raw_results)[[1]] != 200) {

    stop("Something went wrong. You might have put in a wrong location or apiKey. Please check for spelling mistakes and try again.")

  }

  # And we transform the infromation we retrieved from JSON format into a usable format in R .

  my_content <- httr::content(my_raw_results, as = "text")

  my_content_from_json <- jsonlite::fromJSON(my_content)

  return(my_content_from_json)

}

## Example for get_weather
# get_weather("Amsterdam, Niederlande", Sys.getenv("MY_API"))



# This function gets as input whether the user wants the current weather forecast, the hourly forecast,
# or the daily forecast, the location of interest and the apiKey. It returns a list with the desired wheather information.

#' @export
get_your_forecast <- function(cur_hour_day = "current", location, apiKey) {

  full_weather <- get_weather(location, apiKey)

  weather <- NA

  if (cur_hour_day == "current") {

    weather <- full_weather$current

  } else if (cur_hour_day == "hourly") {

    weather <- full_weather$hourly

  } else if (cur_hour_day == "daily") {

    weather <- full_weather$daily

  }

  return(weather)

}

## Example for yourForecast()
# get_your_forecast("hourly", "Amsterdam, Niederlande", Sys.getenv(MY_API))



# This function takes a location (as a string) as input and returns and saves a map of this location using leaflet::leaflet().

#' @export
get_map <- function(location) {

  # first, we need to use the function geocode(location) to get the longitude and the latitude of the desired location.

  latitude <- geocode(location)$latitude
  longitude <- geocode(location)$longitude

  # latitude <- tidygeocoder::geo_osm(location)$lat[1] # old version
  # longitude <- tidygeocoder::geo_osm(location)$long[1] # old version

  if (is.na(latitude) | is.na(longitude)) {

    stop("Please type in a valid location")

  }

  # Retrieve an open map and save it in the object "map" and save ot on the computer.

  map <- leaflet::leaflet() %>%
    leaflet::setView(lng = longitude, lat = latitude, zoom = 11) %>%
    leaflet::addProviderTiles(providers$Stamen.TonerLite, options = providerTileOptions(noWrap = TRUE))
  mapview::mapshot(map, file = "map_plot.png")

  # Now open the png of the map again.

  map <- magick::image_read("map_plot.png")

  return(map)

}

## Example for get_map()
# get_map("Amsterdam, Niederlande")



# This function gets a location and an apiKey as input. It looks for the current weather for the specified location and
# saves and returns a map of the location.
# The map includes icons that correspond to the current weather forecast for this location.

#' @export
get_icon_map <- function(location, apiKey) {

  # first, we need to use the function geocode(location) to get the longitude and the latitude of the desired location.

  latitude <- geocode(location)$latitude
  longitude <- geocode(location)$longitude

  # latitude <- tidygeocoder::geo_osm(location)$lat[1] # old version
  # longitude <- tidygeocoder::geo_osm(location)$long[1] # old version

  if (is.na(latitude) | is.na(longitude)) {

    stop("Please type in a valid location")

  }

  # Then, we use the leafllet() function to retrieve an open map with a specific latitude and longitude and zoom level.
  # And we save it in a file called "map_plot.png".

  map <- leaflet::leaflet() %>%
    leaflet::setView(lng = longitude, lat = latitude, zoom = 12) %>%
    leaflet::addProviderTiles(providers$Stamen.TonerLite, options = providerTileOptions(noWrap = TRUE))
  mapview::mapshot(map, file = "map_plot.png")

  # We retrieve the weather data from the location we are interested in

  my_weather <- get_weather(location, apiKey)

  # We open the map again, that we previously saved.
  # And we open the image of an icon that reflects the current weather we are interested in.

  mymap <- magick::image_scale(image_read(path = "map_plot.png"), "x400")
  imageName <- paste('http://openweathermap.org/img/wn/',my_weather$current$weather$icon, '@2x.png',sep ="")
  icon <- magick::image_scale(image_read(imageName), "x100")

  # Then we merge the map and the icon and save it in the file myMapImage

  img <- c(mymap, icon)
  myMapImage <- magick::image_mosaic(img)

  # And we create another image that uses two instead of one icon on the map.

  image1 <- magick::image_composite(mymap, icon, offset = "+20+20")
  image2 <- magick::image_composite(image1, icon, offset = "+280+180")

  # And we save both images on the computer.

  magick::image_write(myMapImage, path = "my_weather.png", format = "png")
  magick::image_write(image2, path = "my_weather2.png", format = "png")

  return(myMapImage)

}

## Example for get_icon_map()
# get_icon_map("Amsterdam, Niederlande", Sys.getenv("MY_API"))



# This function takes a location (string) and an apiKey (string) as input and returns an image that corresponds
# to the current weather forecast for this location using openweathermap.org

#' @export
get_weather_image <- function(location, apiKey) {

  # Again, we retrieve the  long/lat of the location and the current weather.

  latitude <- geocode(location)$latitude
  longitude <- geocode(location)$longitude

  # latitude <- tidygeocoder::geo_osm(location)$lat[1] # old version
  # longitude <- tidygeocoder::geo_osm(location)$long[1] # old version

  if (is.na(latitude) | is.na(longitude)) {

    stop("Please type in a valid location")

  }

  my_weather <- get_weather(location, apiKey)

  # Now, depending on the current weather at the location, we save a specific image in the object weather_image.

  # If the weather is sunny, store an image of a clear sky in weather_image.

  if (my_weather$current$weather$icon == "01d") {

    weather_image <- magick::image_read("https://user-images.githubusercontent.com/64595164/82326387-09d50900-99dd-11ea-8ca1-fdbc291ab991.jpg")
    magick::image_info(weather_image)
    weather_image <- magick::image_crop(weather_image, "1920x1280")

    # If the weather is cloudly in any way, store an image of a cloudy sky in weather_image.

  } else if (my_weather$current$weather$icon == "02d" | my_weather$current$weather$icon == "03d" | my_weather$current$weather$icon == "04d") {

    weather_image <- magick::image_read("https://user-images.githubusercontent.com/64595164/82326873-cdee7380-99dd-11ea-9899-cd9379a824f9.jpg")
    weather_image <- magick::image_crop(weather_image, "1920x1280")

    # If the weather is rainy, store an image of rain in weather_image.

  } else if (my_weather$current$weather$icon == "09d" | my_weather$current$weather$icon == "10d") {

    weather_image <- magick::image_read("https://user-images.githubusercontent.com/64595164/82326953-e9f21500-99dd-11ea-80f3-5ddc2199632b.jpg")

    # If the weather is a thunderstorm, store an image of a thundestorm in weather_image.

  } else if (my_weather$current$weather$icon == "11d") {

    weather_image <- magick::image_read("https://user-images.githubusercontent.com/64595164/82326999-ffffd580-99dd-11ea-8317-cb0a01de15c7.jpg")

    # If the weather is snowy, store an image of a snowy landschape in weather_image.

  } else if (my_weather$current$weather$icon == "13d") {

    weather_image <- magick::image_read("https://user-images.githubusercontent.com/64595164/82327016-0b530100-99de-11ea-8131-b5e82581945d.jpg")

    # If the weather is misty, store an image of a misty landschape in weather_image.

  } else if (my_weather$current$weather$icon == "50d") {

    weather_image <- magick::image_read("https://user-images.githubusercontent.com/64595164/82327064-232a8500-99de-11ea-814c-e0fe6292dc5f.jpg")

  }

  return(weather_image)

}

## Example for get_weather_image()
# get_weather_image("Amsterdam, Niederlande", Sys.getenv("MY_API"))



# write a function that returns a GIF with weather icons that fly over the map of the users chosen location

#' @export
get_weather_gif <- function(location, apiKey) {

  my_weather <- get_weather(location, apiKey)

  ## create a map and overlay it with the weather icon for the current weather

  # get the map and scale the png file
  map <- get_map(location)
  map <- magick::image_scale(map, "x500")

  # get the icon and scale it
  # icon <- image_read(paste("App-1/www/", my_weather$current$weather$icon,".png", sep=""))
  icon <- magick::image_read(paste('http://openweathermap.org/img/wn/',my_weather$current$weather$icon, '@2x.png',sep =""))
  icon <- magick::image_scale(icon, "x200")

  # create different png files that will make up the GIF
  image1 <- magick::image_composite(map, icon, offset = "+40+20")
  image11 <- magick::image_composite(image1, icon, offset = "+20+250")
  image2 <- magick::image_composite(map, icon, offset = "+120+20")
  image22 <- magick::image_composite(image2, icon, offset = "+100+250")
  image3 <- magick::image_composite(map, icon, offset = "+200+20")
  image33 <- magick::image_composite(image3, icon, offset = "+180+250")
  image4 <- magick::image_composite(map, icon, offset = "+280+20")
  image44 <- magick::image_composite(image4, icon, offset = "+260+250")
  image5 <- magick::image_composite(map, icon, offset = "+360+20")
  image55 <- magick::image_composite(image5, icon, offset = "+340+250")

  # put the different images together to create and interactive GIF
  img <- c(image11, image22, image33, image44, image55)
  animation <- magick::image_animate(image_scale(img, "800x800"), fps = 1, dispose = "previous")

  # save the GIF
  magick::image_write(animation, "my_weather.gif")

  return(animation)

}

## Example for get_weather_gif()
# get_weather_gif("Amsterdam, Niederlande", Sys.getenv("MY_API"))

