library("testthat")
library("weatherApp")

test_check("weatherApp")
